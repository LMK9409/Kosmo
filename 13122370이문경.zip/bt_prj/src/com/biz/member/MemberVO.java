package com.biz.member;

public class MemberVO {
	private int userSeq;
	private String userId;
	private String userName;
	private String userPw;
	private String userGubun;
	private String userEmail;
	private String regdate;
	private String userDel;
	private String ppath;
	private String pname;
	private String sysname;
	private String join_from;
	private String serchGubun;
	private String serchStr;
	
	
	
	public String getSerchGubun() {
		return serchGubun;
	}
	public void setSerchGubun(String serchGubun) {
		this.serchGubun = serchGubun;
	}
	public String getSerchStr() {
		return serchStr;
	}
	public void setSerchStr(String serchStr) {
		this.serchStr = serchStr;
	}
	public String getPpath() {
		return ppath;
	}
	public void setPpath(String ppath) {
		this.ppath = ppath;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getSysname() {
		return sysname;
	}
	public void setSysname(String sysname) {
		this.sysname = sysname;
	}
	public String getJoin_from() {
		return join_from;
	}
	public void setJoin_from(String join_from) {
		this.join_from = join_from;
	}
	public int getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(int userSeq) {
		this.userSeq = userSeq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPw() {
		return userPw;
	}
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	public String getUserGubun() {
		return userGubun;
	}
	public void setUserGubun(String userGubun) {
		this.userGubun = userGubun;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getUserDel() {
		return userDel;
	}
	public void setUserDel(String userDel) {
		this.userDel = userDel;
	}
	
	
	
}
